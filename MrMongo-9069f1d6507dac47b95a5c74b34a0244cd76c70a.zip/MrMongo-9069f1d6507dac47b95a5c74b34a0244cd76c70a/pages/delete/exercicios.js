// Exercicio 01
exercicioComplemento("ex4.1.0", /^deleteOne$/, 'deleteOne')
exercicioComplemento("ex4.1.1", /^"Carlos Silva"$/, "<span class=\"bson_str\">\"Carlos Silva\"</span>")

// Exercicio 02
exercicioComplemento("ex4.2.0", /^deleteOne$/, 'deleteOne')
exercicioComplemento("ex4.2.1", /^id$/, "<span class=\"bson_campo\">id</span>")
exercicioComplemento("ex4.2.2", /^1$/, "<span class=\"bson_num\">1</span>")

// Exercicio 03
exercicioComplemento("ex4.3.0", /^deleteMany$/, 'deleteMany')
exercicioComplemento("ex4.3.1", /^plano$/, "<span class=\"bson_campo\">plano</span>")
exercicioComplemento("ex4.3.2", /^"Mensal"$/, "<span class=\"bson_str\">\"Mensal\"</span>")

// Exercicio 04
exercicioComplemento("ex4.4.0", /^deleteMany$/, 'deleteMany')
exercicioComplemento("ex4.4.1", /^mensalidadePaga$/, "<span class=\"bson_campo\">mensalidadePaga</span>")
exercicioComplemento("ex4.4.2", /^false$/, "<span class=\"bson_bool\">false</span>")
